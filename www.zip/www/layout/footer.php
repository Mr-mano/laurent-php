        
<hr class="featurette-divider"><footer class="container footer">
    <p class="float-right">
        <a href="#"><i class="far fa-arrow-alt-circle-up"></i> Retour haut de page</a>
    </p>
    <p>&copy; Laurent Quéré 2020 &middot;
        <a href="#">Mentions Légales</a>
        &middot;
        <a href="#">Terms</a>
    </p>
</footer>