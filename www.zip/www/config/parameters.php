<?php

define("DB_HOST", "localhost");
define("DB_NAME", "bdd_laurent");
define("DB_USER", "root");
define("DB_PASS", "root");

define("UPLOAD_DIR", "uploads/");
define("SITE_URL", "http://localhost:8888/laurent_quere/www/");