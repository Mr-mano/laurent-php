<?php
	$db = new PDO('mysql:host=localhost;dbname=bdd_laurent;charset=utf8','root', 'root');
?>